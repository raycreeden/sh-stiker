local QBCore = exports['qb-core']:GetCoreObject()

local stickers = {} -- almacen server-side simple (no persistencia en archivos; se pierde al reiniciar recurso)

-- Request sync (cuando un cliente entra)
RegisterNetEvent('sh-stiker:server:requestSync', function()
    local src = source
    TriggerClientEvent('sh-stiker:client:syncAll', src, stickers)
end)

-- Place sticker (cuando un jugador coloca una etiqueta)
RegisterNetEvent('sh-stiker:server:placeSticker', function(x, y, z, text)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local ident = Player and Player.PlayerData.citizenid or tostring(src)

    local st = {
        id = #stickers + 1,
        x = x,
        y = y,
        z = z,
        text = text,
        owner = ident,
        time = os.time()
    }

    table.insert(stickers, st)

    -- Broadcast new sticker a todos los clientes
    if Config.SyncToAll then
        TriggerClientEvent('sh-stiker:client:newSticker', -1, st)
    else
        -- Si quisieras enviar solo a cercanos, acá iría el filtro
        TriggerClientEvent('sh-stiker:client:newSticker', -1, st)
    end
end)

-- Comando admin opcional para ver cuántas etiquetas hay
QBCore.Commands.Add('stikerlist', 'Listar stickers (admin)', {}, false, function(source, args)
    local src = source
    TriggerClientEvent('chat:addMessage', src, {
        args = { 'sh-stiker', 'Total de etiquetas: ' .. tostring(#stickers) }
    })
end, 'god') -- permiso: "god" (podés cambiarlo)

-- Comando: borrar todas las etiquetas del jugador
QBCore.Commands.Add('clearallst', 'Eliminar todas tus etiquetas', {}, false, function(source, args)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local cid = Player.PlayerData.citizenid

    -- eliminar stickers que pertenezcan a este jugador
    local count = 0
    for i = #stickers, 1, -1 do
        if stickers[i].owner == cid then
            table.remove(stickers, i)
            count = count + 1
        end
    end

    -- avisar al cliente que borre los suyos
    TriggerClientEvent('sh-stiker:client:removePlayerStickers', -1, cid)

    TriggerClientEvent('chat:addMessage', src, {
        args = { 'sh-stiker', 'Has eliminado ' .. count .. ' etiquetas.' }
    })
end)

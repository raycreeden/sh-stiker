local QBCore = exports['qb-core']:GetCoreObject()

local stickers = {} -- cache local de stickers del servidor
local placing = false
local previewCoord = nil
local previewText = ""
local nuiOpen = false
local useCam = false
local cam = nil

-- Helpers
local function SetNuiOpen(open)
    nuiOpen = open
    SetNuiFocus(open, open)
    SendNUIMessage({ action = open and "show" or "hide" })
end

-- Abrir / cerrar UI
local function OpenStickerUI()
    if nuiOpen then return end
    SetNuiOpen(true)
end

local function CloseStickerUI()
    if not nuiOpen then return end
    SetNuiOpen(false)
end

-- Registrar comando y tecla
RegisterCommand('sh-stiker:toggleui', function()
    OpenStickerUI()
end)

RegisterKeyMapping('sh-stiker:toggleui', 'Abrir Stiker UI', 'keyboard', Config.OpenKey)

RegisterCommand(Config.Command, function()
    OpenStickerUI()
end, false)

-- NUI callbacks
RegisterNUICallback('cancel', function(_, cb)
    CloseStickerUI()
    cb('ok')
end)

RegisterNUICallback('useSticker', function(data, cb)
    local text = tostring(data.text or "")
    if text == "" then
        cb({ status = 'error', msg = 'Texto vacío' })
        return
    end
    CloseStickerUI()
    previewText = text
    placing = true
    cb({ status = 'ok' })
end)

-- Cancelar colocación
local function CancelPlacement()
    placing = false
    previewCoord = nil
    previewText = ""
    if useCam and cam then
        RenderScriptCams(false, false, 0, true, true)
        DestroyCam(cam, false)
        cam = nil
        useCam = false
    end
end

-- Raycast desde la cámara
local function RaycastFromCamera(maxRange)
    local camPos = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local rot = camRot
    local z = math.rad(rot.z)
    local x = math.rad(rot.x)
    local cosz = math.cos(z)
    local sinz = math.sin(z)
    local cosy = math.cos(x)
    local siny = math.sin(x)

    local forward = vector3(-sinz * cosy, cosz * cosy, siny)
    local dest = camPos + forward * maxRange

    local rayHandle = StartShapeTestRay(camPos.x, camPos.y, camPos.z, dest.x, dest.y, dest.z, -1, PlayerPedId(), 0)
    local _, hit, endCoords, _, _ = GetShapeTestResult(rayHandle)
    if hit == 1 then
        return true, endCoords
    else
        return false, dest
    end
end

-- Dibujar texto 3D
local function Draw3DText(x, y, z, text, scale)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local p = GetGameplayCamCoords()
    local distance = #(p - vector3(x, y, z))
    scale = scale or (1.0 / distance) * 1.0
    if onScreen then
        SetTextScale(0.0 * scale, 1.90 * scale)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextCentre(true)
        SetTextDropshadow(1, 1, 1, 1, 255)
        SetTextEdge(1, 0, 0, 0, 255)
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

-- Bucle principal
Citizen.CreateThread(function()
    while true do
        local waitt = 1000
        local playerPed = PlayerPedId()
        local pcoords = GetEntityCoords(playerPed)

        -- Dibujar etiquetas cercanas
        if #stickers > 0 then
            for _, st in pairs(stickers) do
                local dist = #(pcoords - vector3(st.x, st.y, st.z))
                if dist <= Config.DisplayDistance then
                    Draw3DText(st.x, st.y, st.z + 0.15, st.text)
                    waitt = 0
                end
            end
        end

        -- Modo colocación
        if placing then
            local hit, pos = RaycastFromCamera(Config.MaxRange)
            previewCoord = pos
            DrawMarker(Config.MarkerType, pos.x, pos.y, pos.z + Config.MarkerOffsetZ,
                0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                Config.MarkerScale.x, Config.MarkerScale.y, Config.MarkerScale.z,
                255, 255, 255, 200, false, false, 2, false, nil, nil, false)

            Draw3DText(pos.x, pos.y, pos.z + 0.25, previewText .. " (Preview)")

            -- Colocar
            if IsControlJustPressed(0, 38) then -- E
                if previewCoord then
                    TriggerServerEvent('sh-stiker:server:placeSticker',
                        previewCoord.x, previewCoord.y, previewCoord.z, previewText)
                    CancelPlacement()
                end
            end

            -- Cancelar con ESC
            if IsControlJustPressed(0, 200) then
                CancelPlacement()
            end

            waitt = 0
        end

        Citizen.Wait(waitt)
    end
end)

-- Eventos de sincronización
RegisterNetEvent('sh-stiker:client:syncAll', function(serverStickers)
    stickers = serverStickers or {}
end)

RegisterNetEvent('sh-stiker:client:newSticker', function(st)
    table.insert(stickers, st)
end)

-- Al iniciar recurso
AddEventHandler('onClientResourceStart', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        TriggerServerEvent('sh-stiker:server:requestSync')
    end
end)

-- Limpieza al parar recurso
AddEventHandler('onClientResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        SetNuiOpen(false)
        CancelPlacement()
    end
end)

RegisterNetEvent('sh-stiker:client:removePlayerStickers', function(cid)
    for i = #stickers, 1, -1 do
        if stickers[i].owner == cid then
            table.remove(stickers, i)
        end
    end
end)

RegisterNUICallback('clearStickers', function(data, cb)
    -- llama al comando del server
    ExecuteCommand('clearallst')
    cb('ok')
end)


# sistema de etiquetas personalizados, par mas profundidad de rol
 -  poner dentro de resourse y luego poner [ensure sh-stiker] y listo a correr 
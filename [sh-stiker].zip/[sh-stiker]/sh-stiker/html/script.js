window.addEventListener('message', function(event) {
    const d = event.data;
    if (d.action === 'show') {
        document.getElementById('app').classList.remove('hidden');
        document.getElementById('stickerText').value = '';
        document.getElementById('stickerText').focus();
    } else if (d.action === 'hide') {
        document.getElementById('app').classList.add('hidden');
    }
});

// Buttons
document.getElementById('cancelBtn').addEventListener('click', function() {
    fetch(`https://${GetParentResourceName()}/cancel`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) })
    .then(res => res.json()).then(()=>{});
});

document.getElementById('useBtn').addEventListener('click', function() {
    const text = document.getElementById('stickerText').value;
    fetch(`https://${GetParentResourceName()}/useSticker`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text })
    }).then(res => res.json()).then((data) => {
        // opcional: manejar respuesta
    });
});
// Botón de limpiar etiquetas
document.getElementById('clearBtn').addEventListener('click', function() {
    fetch(`https://${GetParentResourceName()}/clearStickers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    }).then(res => res.json()).then(()=>{});
});


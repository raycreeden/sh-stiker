-- Config para sh-stiker
Config = {}

-- Key por defecto para abrir la UI (control key code para RegisterKeyMapping — usamos 'K' por defecto)
Config.OpenKey = 'K' -- puedes cambiar a la letra que quieras (se registra como mapping "sh-stiker:open")

-- Comando para abrir
Config.Command = 'stiker'

-- Rango máximo (m) para raycast / colocación desde la cámara
Config.MaxRange = 20.0

-- Distancia (m) a la que otros jugadores verán las etiquetas
Config.DisplayDistance = 10.0 -- por defecto 10m (lo querías así)

-- Si true, intentará usar una "cámara flotante" para preview. False por defecto.
Config.UseFloatingCam = false

-- Marker settings (para preview local)
Config.MarkerType = 2 -- tipo DrawMarker
Config.MarkerScale = {x = 0.2, y = 0.2, z = 0.2}
Config.MarkerOffsetZ = 0.0

-- Opciones de sync
Config.SyncToAll = true -- si true, broadcast a todos; la visibilidad real depende de DisplayDistance

-- NUI settings (no tocar)
Config.NUI = {
    width = 300,
   height = 120
}
